package com.fieldops;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FieldopsApplicationTests {

	@Test
	void contextLoads() {
	}

}
